//
//  Passenger.m
//  College Demo
//
//  Created by mashujun on 2022/7/18.
//

#import "Passenger.h"


@implementation Orders
- (instancetype)destination:(Address*) Destination startTime:(NSDate*) StartTime endTime:(NSDate*) EndTime orderID:(NSString*) OrderID{
    self.destination = Destination;
    self.startTime = StartTime;
    self.endTime = EndTime;
    self.orderID = OrderID;
    return self;
}
@end

@implementation Passenger

- (void) initialize{
    _historyOrder = [NSMutableArray array];
    _unusedOrder = [NSMutableArray array];
}

- (void) reserve:(Orders*)order{
    if(_whetherOver18==YES)
    {
        [_unusedOrder addObject:order];
        NSLog(@"Order sucessfully");
    }
    else
        NSLog(@"You are too young to order a ticket by yourself");
        
    
}

- (void) check:(Orders *)order{
    for(NSInteger i = 0;i<[_unusedOrder count];i++)
    {
        if(_unusedOrder[i]==order.orderID)
        {
            [_historyOrder addObject:_unusedOrder[i]];
            [_unusedOrder removeObject:_unusedOrder[i]];
            NSLog(@"Check sucessfully");
            break;
        }
        else
            NSLog(@"OrderID does not exist");
    }
}

@end
