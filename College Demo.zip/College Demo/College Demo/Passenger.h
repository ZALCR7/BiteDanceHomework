//
//  Passenger.h
//  College Demo
//
//  Created by mashujun on 2022/7/18.
//

#import "Person.h"

NS_ASSUME_NONNULL_BEGIN

@interface Orders : NSObject

@property (nonatomic, strong) Address *destination;
@property (nonatomic, strong) NSDate *startTime;
@property (nonatomic, strong) NSDate *endTime;
@property (nonatomic, assign) NSString *orderID;

- (instancetype)destination:(Address*) Destination startTime:(NSDate*) StartTime endTime:(NSDate*) EndTime orderID:(NSString*) OrderID;

@end

@interface Passenger : Person
// @property 属性
// 是否年满 18 岁
// 历史订单 （数组）
// 未出行订单 （数组）

@property (nonatomic, assign) BOOL whetherOver18;
@property (nonatomic, assign) NSMutableArray *historyOrder;
@property (nonatomic, assign) NSMutableArray *unusedOrder;
	
// Function 方法
- (void) initialize;

// 去订票
- (void)reserve:(Orders*)order;

// 去检票
- (void)check:(Orders*)order;
@end

NS_ASSUME_NONNULL_END
