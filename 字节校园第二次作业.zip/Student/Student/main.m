//
//  main.m
//  Student
//
//  Created by zzy on 2022/7/18.
//  Copyright © 2022年 ZhangZhaoyang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"
@implementation Student
-(void)study:(float)time
{
    NSLog(@"The study time of student is %.2f hours",time);
    
}
@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        Student *student = [[Student alloc] init];
        [student study:1.0];
    }
    return 0;
    
}

