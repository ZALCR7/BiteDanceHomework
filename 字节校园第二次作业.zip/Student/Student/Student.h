//
//  Student.h
//  Student
//
//  Created by zzy on 2022/7/18.
//  Copyright © 2022年 ZhangZhaoyang. All rights reserved.
//

#ifndef Student_h
#define Student_h
#import <Foundation/Foundation.h>

@interface Student:NSObject

@property (nonatomic,copy)NSString *name;
@property (nonatomic,copy)NSString *major;
@property (nonatomic,assign)NSUInteger age;

-(void) study :(float)time;

@end

#endif /* Student_h */
